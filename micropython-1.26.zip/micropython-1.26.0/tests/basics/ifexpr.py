# test if-expressions

print(1 if 0 else 2)
print(3 if 1 else 4)

def f(x):
    print('a' if x else 'b')
f([])
f([1])
