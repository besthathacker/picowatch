This directory contains libraries, utilities and helper code developed
specifically for this project.  The code is intended to be portable and
usable by any port.
