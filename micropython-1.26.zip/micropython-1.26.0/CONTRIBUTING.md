When reporting an issue and especially submitting a pull request, please
make sure that you are acquainted with Contributor Guidelines:

https://github.com/micropython/micropython/wiki/ContributorGuidelines

as well as the Code Conventions, which includes details of how to commit:

https://github.com/micropython/micropython/blob/master/CODECONVENTIONS.md
